<div class="index-form">
<form id="reg">
<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
<input type="email" id="regemail" class="form-control" placeholder="e-mail" required />
</div>

<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
<input type="text" id="name" class="form-control" placeholder="Name" required />
</div>

<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span></span>
<input type="text" id="info" class="form-control" placeholder="Info" />
</div>

<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
<input type="password" id="regpass" class="form-control" placeholder="Password" required />
</div>

<div class="input-group">
<span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
<input type="password" id="regpassr" class="form-control" placeholder="Confirm Password" required />
</div>

<button type="submit" class="btn btn-labeled btn-primary">
<span class="btn-label"><i class="glyphicon glyphicon-ok"></i></span>Registration</button>
</form>
<div id="result">
</div>
</div>
